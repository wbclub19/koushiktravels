import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';
import { isAuthenticated, updateSubscriptionDays } from './utils/auth';

function App() {
  const location = useLocation();

  useEffect(() => {
    // Check if user is authenticated and update subscription days
    // This is a simplified approach, typically this would be handled by a server
    if (isAuthenticated()) {
      updateSubscriptionDays();
    }
  }, [location.pathname]);

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Layout>
  );
}

export default App;