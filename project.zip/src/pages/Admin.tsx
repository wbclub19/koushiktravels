import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserPlus, Search, Clock, Users, AlertTriangle } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import Toast from '../components/Toast';
import { isAuthenticated, isAdmin } from '../utils/auth';
import { getUsers, getUserByUsername, addUser, updateUser, deleteUser, getHistory } from '../utils/storage';
import { User, History } from '../types';

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const [tab, setTab] = useState<'addUser' | 'manageUsers' | 'history'>('addUser');
  const [users, setUsers] = useState<User[]>([]);
  const [historyItems, setHistoryItems] = useState<History[]>([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' | 'warning' } | null>(null);
  
  // Add user form state
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [daysToAdd, setDaysToAdd] = useState(30);
  
  // Search user state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [additionalDays, setAdditionalDays] = useState(0);

  // Check if user is admin
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate('/login');
      return;
    }
    
    if (!isAdmin()) {
      navigate('/dashboard');
      return;
    }
    
    // Load users and history
    fetchUsers();
    fetchHistory();
  }, [navigate]);

  const fetchUsers = () => {
    setUsers(getUsers());
  };

  const fetchHistory = () => {
    setHistoryItems(getHistory().sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    ));
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Check if username already exists
      const existingUser = getUserByUsername(newUsername);
      
      if (existingUser) {
        setToast({
          message: 'Username already exists. Please choose a different username.',
          type: 'error'
        });
        setLoading(false);
        return;
      }
      
      // Add new user
      const user = addUser({
        username: newUsername,
        password: newPassword,
        role: 'user',
        daysRemaining: daysToAdd
      });
      
      setUsers([...users, user]);
      
      // Reset form
      setNewUsername('');
      setNewPassword('');
      setDaysToAdd(30);
      
      setToast({
        message: 'User added successfully!',
        type: 'success'
      });
    } catch (error) {
      console.error('Error adding user:', error);
      setToast({
        message: 'Failed to add user. Please try again.',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setSelectedUser(null);
      return;
    }
    
    const results = users.filter(user => 
      user.username.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    setSearchResults(results);
    setSelectedUser(null);
  };

  const handleSelectUser = (user: User) => {
    setSelectedUser(user);
    setAdditionalDays(0);
  };

  const handleAddDays = () => {
    if (!selectedUser || additionalDays <= 0) return;
    
    try {
      const updatedUser = updateUser(selectedUser.id, {
        daysRemaining: selectedUser.daysRemaining + additionalDays
      });
      
      if (updatedUser) {
        setSelectedUser(updatedUser);
        
        // Update users list
        fetchUsers();
        
        setToast({
          message: `Added ${additionalDays} days to ${updatedUser.username}`,
          type: 'success'
        });
        
        setAdditionalDays(0);
      }
    } catch (error) {
      console.error('Error adding days:', error);
      setToast({
        message: 'Failed to add days. Please try again.',
        type: 'error'
      });
    }
  };

  const handleDeleteUser = () => {
    if (!selectedUser) return;
    
    if (window.confirm(`Are you sure you want to delete user ${selectedUser.username}?`)) {
      try {
        if (deleteUser(selectedUser.id)) {
          // Update users list
          fetchUsers();
          
          setToast({
            message: `User ${selectedUser.username} deleted successfully`,
            type: 'success'
          });
          
          setSelectedUser(null);
          setSearchResults(searchResults.filter(user => user.id !== selectedUser.id));
        }
      } catch (error) {
        console.error('Error deleting user:', error);
        setToast({
          message: 'Failed to delete user. Please try again.',
          type: 'error'
        });
      }
    }
  };

  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Admin Dashboard</h1>
        <p className="text-lg">Manage users and view system history</p>
      </div>

      {/* Tabs */}
      <div className="mb-8 border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-2">
          <button
            onClick={() => setTab('addUser')}
            className={`py-3 px-4 text-sm font-medium border-b-2 ${
              tab === 'addUser' 
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent hover:border-gray-300'
            }`}
          >
            <UserPlus className="inline-block mr-2" size={18} />
            Add User
          </button>
          <button
            onClick={() => setTab('manageUsers')}
            className={`py-3 px-4 text-sm font-medium border-b-2 ${
              tab === 'manageUsers' 
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent hover:border-gray-300'
            }`}
          >
            <Users className="inline-block mr-2" size={18} />
            Manage Users
          </button>
          <button
            onClick={() => {
              setTab('history');
              fetchHistory();
            }}
            className={`py-3 px-4 text-sm font-medium border-b-2 ${
              tab === 'history' 
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent hover:border-gray-300'
            }`}
          >
            <Clock className="inline-block mr-2" size={18} />
            History
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {/* Add User Tab */}
        {tab === 'addUser' && (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
            <h2 className="text-xl font-semibold mb-4">Add New User</h2>
            
            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                <label htmlFor="username" className="block text-sm font-medium mb-1">
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                  placeholder="Enter username"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium mb-1">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                  placeholder="Enter password"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="days" className="block text-sm font-medium mb-1">
                  Days of Access
                </label>
                <input
                  type="number"
                  id="days"
                  value={daysToAdd}
                  onChange={(e) => setDaysToAdd(parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                  min="1"
                  required
                />
              </div>
              
              <div className="mt-6">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center items-center px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors disabled:opacity-70"
                >
                  {loading ? (
                    <LoadingSpinner size="small" />
                  ) : (
                    <>
                      <UserPlus className="mr-2\" size={18} />
                      Add User
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
        
        {/* Manage Users Tab */}
        {tab === 'manageUsers' && (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Manage Users</h2>
            
            <div className="mb-6">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyUp={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full px-3 py-2 pl-10 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                  placeholder="Search by username"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
                <button
                  onClick={handleSearch}
                  className="absolute right-2 top-1.5 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded"
                >
                  Search
                </button>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {/* Search Results */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <h3 className="font-medium mb-3">Search Results</h3>
                
                {searchResults.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {searchResults.map((user) => (
                      <div 
                        key={user.id}
                        className={`p-3 rounded-md cursor-pointer transition-colors ${
                          selectedUser?.id === user.id 
                            ? 'bg-blue-100 dark:bg-blue-900' 
                            : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                        onClick={() => handleSelectUser(user)}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{user.username}</span>
                          <span className={`text-sm px-2 py-0.5 rounded ${
                            user.daysRemaining > 10 
                              ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' 
                              : user.daysRemaining > 0 
                                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100' 
                                : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                          }`}>
                            {user.daysRemaining} days
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          Role: {user.role}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : searchQuery ? (
                  <p className="text-gray-500 dark:text-gray-400 py-4 text-center">
                    No users found with that username
                  </p>
                ) : (
                  <p className="text-gray-500 dark:text-gray-400 py-4 text-center">
                    Enter a username to search
                  </p>
                )}
              </div>
              
              {/* User Management */}
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <h3 className="font-medium mb-3">User Management</h3>
                
                {selectedUser ? (
                  <div>
                    <div className="mb-4 p-4 bg-gray-100 dark:bg-gray-700 rounded-md">
                      <h4 className="font-semibold">{selectedUser.username}</h4>
                      <p className="text-sm mt-1">Role: {selectedUser.role}</p>
                      <p className={`text-sm mt-1 ${
                        selectedUser.daysRemaining > 10 
                          ? 'text-green-600 dark:text-green-400' 
                          : selectedUser.daysRemaining > 0 
                            ? 'text-yellow-600 dark:text-yellow-400' 
                            : 'text-red-600 dark:text-red-400'
                      }`}>
                        Days remaining: {selectedUser.daysRemaining}
                      </p>
                      <p className="text-sm mt-1 text-gray-600 dark:text-gray-400">
                        Created: {new Date(selectedUser.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="additionalDays" className="block text-sm font-medium mb-1">
                          Add Days
                        </label>
                        <div className="flex">
                          <input
                            type="number"
                            id="additionalDays"
                            value={additionalDays}
                            onChange={(e) => setAdditionalDays(parseInt(e.target.value))}
                            className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-l-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                            min="1"
                          />
                          <button
                            onClick={handleAddDays}
                            disabled={additionalDays <= 0}
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-r-md transition-colors disabled:opacity-70"
                          >
                            Add
                          </button>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleDeleteUser}
                        className="w-full flex justify-center items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors"
                      >
                        <AlertTriangle className="mr-2" size={18} />
                        Delete Account
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500 dark:text-gray-400 py-4 text-center">
                    Select a user to manage
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* History Tab */}
        {tab === 'history' && (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">System History</h2>
            
            {historyItems.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Action
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Details
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Date & Time
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {historyItems.map((item) => (
                      <tr key={item.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {item.action}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {item.details}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {new Date(item.timestamp).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 dark:text-gray-400 py-4 text-center">
                No history records found
              </p>
            )}
          </div>
        )}
      </div>

      {/* Toast notifications */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
};

export default Admin;