import React, { useState, useEffect } from 'react';
import { MapPin, Phone } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { getServices } from '../utils/storage';
import { getCurrentLocation, findNearbyServices } from '../utils/location';
import { Service } from '../types';

const Home: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [nearbyServices, setNearbyServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<{latitude: number, longitude: number} | null>(null);

  useEffect(() => {
    // Fetch all services
    const fetchServices = () => {
      try {
        const allServices = getServices();
        setServices(allServices);
      } catch (err) {
        console.error('Error fetching services:', err);
        setError('Failed to load services. Please try again later.');
      }
    };

    fetchServices();
    
    // Set up interval to refresh services every 30 seconds
    const interval = setInterval(fetchServices, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const handleDetectNearbyServices = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const position = await getCurrentLocation();
      const location = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };
      
      setCurrentLocation(location);
      
      // Find nearby services (within 10km)
      const nearby = findNearbyServices(
        location.latitude,
        location.longitude,
        services,
        10
      );
      
      setNearbyServices(nearby);
    } catch (err) {
      console.error('Error detecting nearby services:', err);
      setError('Failed to detect your location. Please check your GPS settings and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCallService = (phoneNumber: string) => {
    window.location.href = `tel:${phoneNumber}`;
  };

  return (
    <div className="animate-fadeIn">
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Find Travel Services Near You</h1>
        <p className="text-lg opacity-80 max-w-2xl mx-auto">
          KOUSHIK Travels helps you connect with nearby travel services instantly.
          Get quick access to vehicles, drivers, and other travel needs.
        </p>
      </div>

      <div className="mb-10 flex justify-center">
        <button
          onClick={handleDetectNearbyServices}
          disabled={loading}
          className="flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all transform hover:scale-105 shadow-lg disabled:opacity-70"
        >
          {loading ? (
            <>
              <LoadingSpinner size="small" />
              <span className="ml-2">Detecting nearby services...</span>
            </>
          ) : (
            <>
              <MapPin className="mr-2" />
              Detect Nearby Services
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-500 text-white p-4 rounded-lg mb-6 max-w-2xl mx-auto">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {nearbyServices.length > 0 ? (
          nearbyServices.map((service) => (
            <div 
              key={service.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden transform transition-all hover:scale-105 hover:shadow-xl"
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-semibold">{service.vehicleName}</h3>
                  <span className={`px-2 py-1 rounded text-xs ${service.isLive ? 'bg-green-500 text-white' : 'bg-gray-300 dark:bg-gray-600'}`}>
                    {service.isLive ? 'Live' : 'Available'}
                  </span>
                </div>
                
                <p className="flex items-start mb-3">
                  <MapPin size={18} className="mr-2 mt-1 flex-shrink-0 text-gray-500" />
                  <span>{service.address}</span>
                </p>
                
                <button
                  onClick={() => handleCallService(service.phoneNumber)}
                  className="mt-4 w-full flex items-center justify-center px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                >
                  <Phone className="mr-2" />
                  <span className="text-lg font-bold">{service.phoneNumber}</span>
                </button>
              </div>
            </div>
          ))
        ) : services.length > 0 ? (
          <div className="col-span-full text-center py-10">
            <p className="text-xl mb-4">
              {currentLocation 
                ? "No services found nearby. Try expanding your search area." 
                : "Tap 'Detect Nearby Services' to find travel services around you."}
            </p>
          </div>
        ) : (
          <div className="col-span-full text-center py-10">
            <p className="text-xl">No services available at the moment. Please check back later.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;