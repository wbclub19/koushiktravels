import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, PhoneCall, Truck, Send, X } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import Toast from '../components/Toast';
import { isAuthenticated, hasValidSubscription } from '../utils/auth';
import { getCurrentLocation, getAddressFromCoordinates } from '../utils/location';
import { getCurrentUser, addService, getUserServices, updateService, deleteService } from '../utils/storage';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(getCurrentUser());
  const [services, setServices] = useState(user ? getUserServices(user.id) : []);
  const [isLiveLocation, setIsLiveLocation] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' | 'warning' } | null>(null);
  
  // Form state
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [vehicleName, setVehicleName] = useState('');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  
  // Check authentication and subscription status
  useEffect(() => {
    if (!isAuthenticated()) {
      navigate('/login');
      return;
    }
    
    if (!hasValidSubscription()) {
      setToast({
        message: 'Your subscription has expired. Please contact 7908733249 to renew.',
        type: 'warning'
      });
    }
    
    // Get user and their services
    const currentUser = getCurrentUser();
    setUser(currentUser);
    
    if (currentUser) {
      const userServices = getUserServices(currentUser.id);
      setServices(userServices);
    }
  }, [navigate]);
  
  // Live location tracking setup
  useEffect(() => {
    let watchId: number | null = null;
    
    if (isLiveLocation && user) {
      watchId = navigator.geolocation.watchPosition(
        async (position) => {
          const newLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          
          setLocation(newLocation);
          
          // If user has existing service, update its location
          if (services.length > 0) {
            const service = services[0];
            const newAddress = await getAddressFromCoordinates(
              newLocation.latitude,
              newLocation.longitude
            );
            
            const updatedService = updateService(service.id, {
              location: newLocation,
              address: newAddress,
              isLive: true
            });
            
            if (updatedService) {
              setServices([updatedService]);
            }
          }
        },
        (error) => {
          console.error('Error tracking location:', error);
          setToast({
            message: 'Failed to track location. Please check your GPS settings.',
            type: 'error'
          });
          setIsLiveLocation(false);
        },
        { enableHighAccuracy: true }
      );
    }
    
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [isLiveLocation, services, user]);

  const handleDetectLocation = async () => {
    setIsDetectingLocation(true);
    
    try {
      const position = await getCurrentLocation();
      const detectedLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };
      
      setLocation(detectedLocation);
      
      // Get address from coordinates
      const detectedAddress = await getAddressFromCoordinates(
        detectedLocation.latitude,
        detectedLocation.longitude
      );
      
      setAddress(detectedAddress);
      
      setToast({
        message: 'Location detected successfully!',
        type: 'success'
      });
    } catch (error) {
      console.error('Error detecting location:', error);
      setToast({
        message: 'Failed to detect location. Please check your GPS settings.',
        type: 'error'
      });
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    if (!location) {
      setToast({
        message: 'Please detect your location first',
        type: 'warning'
      });
      return;
    }
    
    try {
      // Create new service
      const newService = addService({
        userId: user.id,
        phoneNumber,
        address,
        vehicleName,
        location,
        isLive: isLiveLocation,
        createdAt: new Date().toISOString()
      });
      
      setServices([...services, newService]);
      
      // Reset form
      setPhoneNumber('');
      setAddress('');
      setVehicleName('');
      
      setToast({
        message: 'Service added successfully!',
        type: 'success'
      });
    } catch (error) {
      console.error('Error adding service:', error);
      setToast({
        message: 'Failed to add service. Please try again.',
        type: 'error'
      });
    }
  };

  const toggleLiveLocation = () => {
    if (isLiveLocation) {
      // Update all services to not live
      if (services.length > 0) {
        const updatedServices = services.map(service => {
          const updated = updateService(service.id, { isLive: false });
          return updated || service;
        });
        
        setServices(updatedServices.filter(Boolean));
      }
      
      setIsLiveLocation(false);
      setToast({
        message: 'Live location sharing stopped',
        type: 'info'
      });
    } else {
      setIsLiveLocation(true);
      setToast({
        message: 'Live location sharing started',
        type: 'success'
      });
    }
  };

  const handleDeleteService = (serviceId: string) => {
    if (deleteService(serviceId)) {
      setServices(services.filter(service => service.id !== serviceId));
      setToast({
        message: 'Service deleted successfully',
        type: 'success'
      });
    }
  };

  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        {user && (
          <p className="text-lg">
            Welcome, <span className="font-semibold">{user.username}</span>
            {user.role === 'user' && (
              <span className="ml-2">
                (Days remaining: <span className="font-bold">{user.daysRemaining}</span>)
              </span>
            )}
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Add Service Form */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Add Your Service</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="phoneNumber" className="block text-sm font-medium mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                id="phoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                placeholder="Your contact number"
                required
              />
            </div>
            
            <div>
              <label htmlFor="vehicleName" className="block text-sm font-medium mb-1">
                Vehicle Name/Type
              </label>
              <input
                type="text"
                id="vehicleName"
                value={vehicleName}
                onChange={(e) => setVehicleName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                placeholder="E.g., Tata Sumo, Auto Rickshaw"
                required
              />
            </div>
            
            <div className="relative">
              <label htmlFor="address" className="block text-sm font-medium mb-1">
                Address
              </label>
              <textarea
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700"
                placeholder="Your current location address"
                rows={3}
                required
              ></textarea>
              
              <button
                type="button"
                onClick={handleDetectLocation}
                className="mt-2 inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                disabled={isDetectingLocation}
              >
                {isDetectingLocation ? (
                  <>
                    <LoadingSpinner size="small" />
                    <span className="ml-2">Detecting...</span>
                  </>
                ) : (
                  <>
                    <MapPin className="mr-1" size={18} />
                    Detect Location
                  </>
                )}
              </button>
            </div>
            
            <div className="mt-6">
              <button
                type="submit"
                className="w-full flex justify-center items-center px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors"
              >
                <Send className="mr-2" size={18} />
                Submit Service
              </button>
            </div>
          </form>
          
          <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={toggleLiveLocation}
              className={`w-full flex justify-center items-center px-4 py-3 rounded-md transition-colors ${
                isLiveLocation
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {isLiveLocation ? (
                <>
                  <X className="mr-2\" size={18} />
                  Stop Sharing Live Location
                </>
              ) : (
                <>
                  <MapPin className="mr-2" size={18} />
                  Share Live Location
                </>
              )}
            </button>
            {isLiveLocation && (
              <p className="mt-2 text-sm text-green-600 dark:text-green-400">
                Live location sharing is active. Your location is being updated in real-time.
              </p>
            )}
          </div>
        </div>
        
        {/* Your Services */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Your Services</h2>
          
          {services.length > 0 ? (
            <div className="space-y-4">
              {services.map((service) => (
                <div 
                  key={service.id}
                  className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 relative"
                >
                  <div className="flex justify-between">
                    <h3 className="font-medium">{service.vehicleName}</h3>
                    <span className={`px-2 py-1 rounded text-xs ${
                      service.isLive ? 'bg-green-500 text-white' : 'bg-gray-300 dark:bg-gray-600'
                    }`}>
                      {service.isLive ? 'Live' : 'Static'}
                    </span>
                  </div>
                  
                  <div className="mt-2 space-y-2">
                    <p className="flex items-center text-sm">
                      <PhoneCall size={16} className="mr-2 text-gray-500" />
                      {service.phoneNumber}
                    </p>
                    <p className="flex items-start text-sm">
                      <MapPin size={16} className="mr-2 mt-1 flex-shrink-0 text-gray-500" />
                      <span>{service.address}</span>
                    </p>
                    <p className="flex items-center text-sm">
                      <Truck size={16} className="mr-2 text-gray-500" />
                      {service.vehicleName}
                    </p>
                  </div>
                  
                  <button
                    onClick={() => handleDeleteService(service.id)}
                    className="mt-3 text-sm text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">
                You haven't added any services yet. Use the form to add your first service.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Toast notifications */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
};

export default Dashboard;