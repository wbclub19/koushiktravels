import { User, Service, History } from '../types';

// Local storage keys
const USERS_KEY = 'koushik_users';
const SERVICES_KEY = 'koushik_services';
const HISTORY_KEY = 'koushik_history';
const CURRENT_USER_KEY = 'koushik_current_user';

// Initialize storage
export const initializeStorage = (): void => {
  if (!localStorage.getItem(USERS_KEY)) {
    localStorage.setItem(USERS_KEY, JSON.stringify([
      {
        id: '1',
        username: 'admin',
        password: 'admin123',
        role: 'admin',
        daysRemaining: 9999,
        createdAt: new Date().toISOString()
      }
    ]));
  }
  
  if (!localStorage.getItem(SERVICES_KEY)) {
    localStorage.setItem(SERVICES_KEY, JSON.stringify([]));
  }
  
  if (!localStorage.getItem(HISTORY_KEY)) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify([]));
  }
};

// User functions
export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

export const getUserByUsername = (username: string): User | undefined => {
  const users = getUsers();
  return users.find(user => user.username === username);
};

export const addUser = (user: Omit<User, 'id' | 'createdAt'>): User => {
  const users = getUsers();
  const newUser = {
    ...user,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  };
  
  localStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));
  addHistory('User Added', `Admin added user: ${newUser.username}`);
  return newUser;
};

export const updateUser = (userId: string, updates: Partial<User>): User | null => {
  const users = getUsers();
  const index = users.findIndex(user => user.id === userId);
  
  if (index === -1) return null;
  
  const updatedUser = { ...users[index], ...updates };
  users[index] = updatedUser;
  
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  addHistory('User Updated', `Updated user: ${updatedUser.username}`);
  return updatedUser;
};

export const deleteUser = (userId: string): boolean => {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  
  if (!user) return false;
  
  const filteredUsers = users.filter(user => user.id !== userId);
  localStorage.setItem(USERS_KEY, JSON.stringify(filteredUsers));
  addHistory('User Deleted', `Deleted user: ${user.username}`);
  return true;
};

// Service functions
export const getServices = (): Service[] => {
  const services = localStorage.getItem(SERVICES_KEY);
  return services ? JSON.parse(services) : [];
};

export const getUserServices = (userId: string): Service[] => {
  const services = getServices();
  return services.filter(service => service.userId === userId);
};

export const addService = (service: Omit<Service, 'id' | 'createdAt'>): Service => {
  const services = getServices();
  const newService = {
    ...service,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  };
  
  localStorage.setItem(SERVICES_KEY, JSON.stringify([...services, newService]));
  addHistory('Service Added', `User added service: ${newService.vehicleName}`);
  return newService;
};

export const updateService = (serviceId: string, updates: Partial<Service>): Service | null => {
  const services = getServices();
  const index = services.findIndex(service => service.id === serviceId);
  
  if (index === -1) return null;
  
  const updatedService = { ...services[index], ...updates };
  services[index] = updatedService;
  
  localStorage.setItem(SERVICES_KEY, JSON.stringify(services));
  addHistory('Service Updated', `Updated service: ${updatedService.vehicleName}`);
  return updatedService;
};

export const deleteService = (serviceId: string): boolean => {
  const services = getServices();
  const filteredServices = services.filter(service => service.id !== serviceId);
  
  if (filteredServices.length === services.length) return false;
  
  localStorage.setItem(SERVICES_KEY, JSON.stringify(filteredServices));
  addHistory('Service Deleted', 'Deleted a service');
  return true;
};

// History functions
export const getHistory = (): History[] => {
  const history = localStorage.getItem(HISTORY_KEY);
  return history ? JSON.parse(history) : [];
};

export const addHistory = (action: string, details: string): History => {
  const history = getHistory();
  const newHistoryItem = {
    id: Date.now().toString(),
    action,
    details,
    timestamp: new Date().toISOString()
  };
  
  localStorage.setItem(HISTORY_KEY, JSON.stringify([...history, newHistoryItem]));
  return newHistoryItem;
};

// Authentication functions
export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

export const login = (username: string, password: string): User | null => {
  const user = getUserByUsername(username);
  
  if (user && user.password === password) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    addHistory('User Login', `User logged in: ${user.username}`);
    return user;
  }
  
  return null;
};

export const logout = (): void => {
  const user = getCurrentUser();
  if (user) {
    addHistory('User Logout', `User logged out: ${user.username}`);
  }
  localStorage.removeItem(CURRENT_USER_KEY);
};

// Security helper function to prevent XSS (example)
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};