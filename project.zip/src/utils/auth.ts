import { User } from '../types';
import { getCurrentUser, getUsers, login as storageLogin, logout as storageLogout } from './storage';

// Check if user session is valid
export const isAuthenticated = (): boolean => {
  const user = getCurrentUser();
  return !!user;
};

// Check if user is admin
export const isAdmin = (): boolean => {
  const user = getCurrentUser();
  return user?.role === 'admin';
};

// Login function
export const login = async (username: string, password: string): Promise<{ success: boolean; user?: User; message?: string }> => {
  try {
    // Simple rate limiting for security (would be better on server)
    const loginAttempts = localStorage.getItem('login_attempts') || '0';
    const lastAttempt = localStorage.getItem('last_login_attempt') || '0';
    const now = Date.now();
    
    if (parseInt(loginAttempts) > 5 && now - parseInt(lastAttempt) < 300000) {
      return { 
        success: false, 
        message: 'Too many login attempts. Please try again later.' 
      };
    }
    
    // Update login attempt counter
    localStorage.setItem('login_attempts', (parseInt(loginAttempts) + 1).toString());
    localStorage.setItem('last_login_attempt', now.toString());
    
    // Attempt login
    const user = storageLogin(username, password);
    
    if (user) {
      // Reset attempts on success
      localStorage.setItem('login_attempts', '0');
      return { success: true, user };
    } else {
      return { 
        success: false, 
        message: 'Invalid username or password.' 
      };
    }
  } catch (error) {
    console.error('Login error:', error);
    return { 
      success: false, 
      message: 'An error occurred during login. Please try again.' 
    };
  }
};

// Logout function
export const logout = (): void => {
  storageLogout();
};

// Check if user subscription is valid
export const hasValidSubscription = (): boolean => {
  const user = getCurrentUser();
  return user ? user.daysRemaining > 0 : false;
};

// Decrease subscription day (to be called on login)
export const updateSubscriptionDays = (): void => {
  // This would typically be done on the server side
  // This is a simplified client-side implementation
  const user = getCurrentUser();
  
  if (user && user.role === 'user' && user.daysRemaining > 0) {
    const users = getUsers();
    const updatedUsers = users.map(u => {
      if (u.id === user.id) {
        return { ...u, daysRemaining: u.daysRemaining - 1 };
      }
      return u;
    });
    
    localStorage.setItem('koushik_users', JSON.stringify(updatedUsers));
    
    // Update current user
    const updatedUser = { ...user, daysRemaining: user.daysRemaining - 1 };
    localStorage.setItem('koushik_current_user', JSON.stringify(updatedUser));
  }
};