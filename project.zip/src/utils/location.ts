// Get current location
export const getCurrentLocation = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0
    });
  });
};

// Calculate distance between two points in km
export const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Earth's radius in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
};

// Helper function: Convert degrees to radians
const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};

// Get address from coordinates (reverse geocoding)
export const getAddressFromCoordinates = async (
  latitude: number,
  longitude: number
): Promise<string> => {
  try {
    // For demo purposes we'll just return a hardcoded value
    // In a real app, you would use a geocoding API like Google Maps or Nominatim
    return `Harachandapur, West Bengal 732203 (${latitude.toFixed(5)}, ${longitude.toFixed(5)})`;
  } catch (error) {
    console.error('Error getting address:', error);
    return 'Address not available';
  }
};

// Find nearby services within a certain radius (in km)
export const findNearbyServices = (
  currentLat: number,
  currentLon: number,
  services: Array<{ location: { latitude: number; longitude: number } }>,
  maxDistance: number = 10
): Array<any> => {
  return services.filter((service) => {
    const distance = calculateDistance(
      currentLat,
      currentLon,
      service.location.latitude,
      service.location.longitude
    );
    return distance <= maxDistance;
  });
};