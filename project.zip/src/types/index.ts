export interface User {
  id: string;
  username: string;
  password: string;
  role: 'user' | 'admin';
  daysRemaining: number;
  createdAt: string;
}

export interface Service {
  id: string;
  userId: string;
  phoneNumber: string;
  address: string;
  vehicleName: string;
  location: {
    latitude: number;
    longitude: number;
  };
  isLive: boolean;
  createdAt: string;
}

export interface History {
  id: string;
  action: string;
  details: string;
  timestamp: string;
}